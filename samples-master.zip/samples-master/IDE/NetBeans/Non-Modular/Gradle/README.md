## Non-modular samples for NetBeans

JavaFX samples to run from NetBeans with different options and build tools.

Download [JDK 17 or later](http://jdk.java.net/) for your operating system.
Make sure `JAVA_HOME` is properly set to the JDK installation directory. 

### Gradle

Clone the sample, open it with NetBeans. Select the build.gradle file, and build and run
from the tasks in the Navigator window.