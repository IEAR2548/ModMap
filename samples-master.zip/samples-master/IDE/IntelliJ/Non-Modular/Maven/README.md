## Non-modular samples for IntelliJ

JavaFX samples to run from IntelliJ with different options and build tools

Version IntelliJ IDEA 2019.1

Download [JDK 17 or later](http://jdk.java.net/) for your operating system.
Make sure `JAVA_HOME` is properly set to the JDK installation directory. 

### Maven

Clone the sample, open it with IntelliJ and import the Maven changes. Compile or run
from the Maven Projects window.